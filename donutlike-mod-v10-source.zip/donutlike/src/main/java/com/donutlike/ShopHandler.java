package com.donutlike;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * /shop kieu DonutSMP cu: Menu chinh (27 o) -> Menu con (54 o) -> Chon so luong (27 o, -64 -10 -1 | item | +1 +10 +64).
 * Chi dung chuot trai. Giao dien ao: moi thao tac click deu bi chan, khong the lay do ra khoi GUI.
 */
public class ShopHandler {

    record Entry(Item item, double price) {}

    static final Map<String, List<Entry>> CATALOG = new LinkedHashMap<>();
    static final Map<String, String> CAT_TITLE = new LinkedHashMap<>();

    static void add(String cat, Item it, double price) { CATALOG.computeIfAbsent(cat, k -> new ArrayList<>()).add(new Entry(it, price)); }

    static {
        CAT_TITLE.put("gear", "Gear"); CAT_TITLE.put("nether", "Nether"); CAT_TITLE.put("end", "End"); CAT_TITLE.put("food", "Food");
        // ----- Gear (hang 1: hoi sinh/ho tro, hang 2: block xay nhanh, hang 3+: vu khi giap) -----
        add("gear", Items.TOTEM_OF_UNDYING, 1000); add("gear", Items.GOLDEN_APPLE, 60); add("gear", Items.ENCHANTED_GOLDEN_APPLE, 5000);
        add("gear", Items.EXPERIENCE_BOTTLE, 30); add("gear", Items.ENDER_PEARL, 40); add("gear", Items.WIND_CHARGE, 60);
        add("gear", Items.FIREWORK_ROCKET, 30); add("gear", Items.ARROW, 2); add("gear", Items.SHIELD, 80);
        add("gear", Items.OBSIDIAN, 15); add("gear", Items.CRYING_OBSIDIAN, 25); add("gear", Items.END_CRYSTAL, 150);
        add("gear", Items.RESPAWN_ANCHOR, 400); add("gear", Items.GLOWSTONE, 20); add("gear", Items.TNT, 50);
        add("gear", Items.COBWEB, 20); add("gear", Items.WATER_BUCKET, 20); add("gear", Items.LAVA_BUCKET, 40);
        add("gear", Items.BOW, 60); add("gear", Items.CROSSBOW, 100);
        add("gear", Items.DIAMOND_SWORD, 450); add("gear", Items.DIAMOND_HELMET, 700); add("gear", Items.DIAMOND_CHESTPLATE, 1100);
        add("gear", Items.DIAMOND_LEGGINGS, 1000); add("gear", Items.DIAMOND_BOOTS, 600);
        add("gear", Items.NETHERITE_SWORD, 3500); add("gear", Items.NETHERITE_HELMET, 3500); add("gear", Items.NETHERITE_CHESTPLATE, 4500);
        add("gear", Items.NETHERITE_LEGGINGS, 4200); add("gear", Items.NETHERITE_BOOTS, 3300);
        add("gear", Items.NETHERITE_PICKAXE, 3500); add("gear", Items.NETHERITE_AXE, 3500); add("gear", Items.MACE, 8000);
        add("gear", Items.ELYTRA, 6000);
        // ----- Nether -----
        add("nether", Items.QUARTZ, 8); add("nether", Items.QUARTZ_BLOCK, 32); add("nether", Items.BLAZE_ROD, 40);
        add("nether", Items.NETHER_WART, 12); add("nether", Items.SOUL_SAND, 6); add("nether", Items.MAGMA_BLOCK, 10);
        add("nether", Items.NETHERRACK, 2); add("nether", Items.GLOWSTONE_DUST, 8); add("nether", Items.GHAST_TEAR, 150);
        add("nether", Items.MAGMA_CREAM, 25); add("nether", Items.ANCIENT_DEBRIS, 350); add("nether", Items.NETHERITE_SCRAP, 300);
        add("nether", Items.NETHERITE_INGOT, 1400); add("nether", Items.GOLD_INGOT, 25); add("nether", Items.BASALT, 3);
        add("nether", Items.BLACKSTONE, 3); add("nether", Items.NETHER_BRICKS, 8); add("nether", Items.CRIMSON_STEM, 6);
        add("nether", Items.WARPED_STEM, 6); add("nether", Items.WITHER_SKELETON_SKULL, 5000);
        // ----- End -----
        add("end", Items.SHULKER_BOX, 1500); add("end", Items.SHULKER_SHELL, 600); add("end", Items.ENDER_EYE, 90);
        add("end", Items.ENDER_PEARL, 40); add("end", Items.CHORUS_FRUIT, 12); add("end", Items.END_STONE, 4);
        add("end", Items.END_STONE_BRICKS, 6); add("end", Items.PURPUR_BLOCK, 8); add("end", Items.DRAGON_BREATH, 500);
        add("end", Items.END_ROD, 15); add("end", Items.ENDER_CHEST, 120); add("end", Items.END_CRYSTAL, 150);
        add("end", Items.ELYTRA, 6000);
        // ----- Food -----
        add("food", Items.GOLDEN_CARROT, 20); add("food", Items.BREAD, 5); add("food", Items.COOKED_BEEF, 6);
        add("food", Items.COOKED_PORKCHOP, 6); add("food", Items.COOKED_CHICKEN, 5); add("food", Items.COOKED_MUTTON, 5);
        add("food", Items.COOKED_SALMON, 5); add("food", Items.GOLDEN_APPLE, 60); add("food", Items.APPLE, 3);
        add("food", Items.BAKED_POTATO, 3); add("food", Items.CAKE, 30); add("food", Items.PUMPKIN_PIE, 8);
        add("food", Items.COOKIE, 1); add("food", Items.HONEY_BOTTLE, 15); add("food", Items.MELON_SLICE, 1);
        add("food", Items.SWEET_BERRIES, 2); add("food", Items.GLOW_BERRIES, 3);
    }

    // ===== helpers =====
    static ItemStack icon(Item it, String name, String... lore) {
        ItemStack s = new ItemStack(it);
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name));
        if (lore.length > 0) {
            List<Text> l = new ArrayList<>();
            for (String x : lore) l.add(Text.literal(x));
            s.set(DataComponentTypes.LORE, new LoreComponent(l));
        }
        return s;
    }

    static void fill(SimpleInventory inv) {
        for (int i = 0; i < inv.size(); i++) inv.setStack(i, icon(Items.GRAY_STAINED_GLASS_PANE, " "));
    }

    static void ting(ServerPlayerEntity p) {
        p.getWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1f, 1f);
    }

    /** So o trong con lai trong tui (36 o chinh) cho item nay. */
    static int space(ServerPlayerEntity sp, Item it) {
        int free = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = sp.getInventory().getStack(i);
            if (st.isEmpty()) free += it.getMaxCount();
            else if (st.isOf(it) && st.getComponentChanges().isEmpty()) free += Math.max(0, st.getMaxCount() - st.getCount());
        }
        return free;
    }

    /** Cho cho item co component (vd: do trong /ah). */
    static int spaceFor(ServerPlayerEntity sp, ItemStack ref) {
        int free = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack st = sp.getInventory().getStack(i);
            if (st.isEmpty()) free += ref.getMaxCount();
            else if (ItemStack.areItemsAndComponentsEqual(st, ref)) free += Math.max(0, st.getMaxCount() - st.getCount());
        }
        return free;
    }

    static boolean canReceiveStack(ServerPlayerEntity sp, ItemStack ref) {
        if (Admin.on("shop_dropfull")) return true;
        if (spaceFor(sp, ref) >= ref.getCount()) return true;
        DonutLike.msg(sp, "§cTúi đồ đầy! Hãy dọn chỗ trống rồi thử lại.");
        return false;
    }

    /** Neu tat "shop_dropfull" thi tui day khong cho mua; bat thi do roi xuong dat. */
    static boolean canReceive(ServerPlayerEntity sp, Item it, int amount) {
        if (Admin.on("shop_dropfull")) return true;
        if (space(sp, it) >= amount) return true;
        DonutLike.msg(sp, "§cTúi đồ đầy! Hãy dọn chỗ trống rồi mua tiếp.");
        return false;
    }

    static void later(ServerPlayerEntity sp, Runnable r) { sp.getServer().execute(r); }

    // ===== 1) MENU CHINH =====
    public static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Main(id, inv, new SimpleInventory(27)), Text.literal("Shop")));
    }

    static class Main extends GenericContainerScreenHandler {
        Main(int id, PlayerInventory pinv, SimpleInventory inv) {
            super(ScreenHandlerType.GENERIC_9X3, id, pinv, inv, 3);
            fill(inv);
            inv.setStack(11, icon(Items.NETHERITE_SWORD, "§c§lGear", "§7Trang bị PvP", "§eClick để mở"));
            inv.setStack(12, icon(Items.QUARTZ_BLOCK, "§6§lNether", "§7Nguyên liệu Địa ngục", "§eClick để mở"));
            inv.setStack(13, icon(Items.SHULKER_BOX, "§5§lEnd", "§7Vật phẩm cao cấp", "§eClick để mở"));
            inv.setStack(14, icon(Items.GOLDEN_CARROT, "§a§lFood", "§7Thức ăn", "§eClick để mở"));
            inv.setStack(15, icon(Items.EMERALD, "§d§lShard Shop", "§7Đổi điểm Shard", "§eClick để mở"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && button == 0) {
                switch (slot) {
                    case 11 -> later(sp, () -> Category.open(sp, "gear", 0));
                    case 12 -> later(sp, () -> Category.open(sp, "nether", 0));
                    case 13 -> later(sp, () -> Category.open(sp, "end", 0));
                    case 14 -> later(sp, () -> Category.open(sp, "food", 0));
                    case 15 -> later(sp, () -> ShardShop.open(sp));
                    default -> { }
                }
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    // ===== 2) MENU CON (54 o) =====
    static class Category extends GenericContainerScreenHandler {
        final String cat; final int page; final List<Entry> list;
        static final int PER = 45;

        static void open(ServerPlayerEntity p, String cat, int page) {
            p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, inv, pl) -> new Category(id, inv, new SimpleInventory(54), cat, page),
                Text.literal("Shop - " + CAT_TITLE.get(cat))));
        }

        Category(int id, PlayerInventory pinv, SimpleInventory inv, String cat, int page) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.cat = cat; this.page = page; this.list = CATALOG.getOrDefault(cat, List.of());
            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            for (int i = 0; i < PER; i++) {
                int idx = page * PER + i;
                if (idx >= list.size()) break;
                Entry e = list.get(idx);
                ItemStack d = new ItemStack(e.item());
                d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§7" + new ItemStack(e.item()).getName().getString()),
                    Text.literal("§eBuy Price: §a$" + Prices.money(e.price())),
                    Text.literal("§aClick để chọn số lượng"))));
                inv.setStack(i, d);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, icon(Items.GRAY_STAINED_GLASS_PANE, " "));
            inv.setStack(49, icon(Items.ARROW, "§eQuay lại"));
            if (page > 0) inv.setStack(45, icon(Items.ARROW, "§e← Trang trước"));
            if ((page + 1) * PER < list.size()) inv.setStack(53, icon(Items.ARROW, "§eTrang sau →"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && button == 0 && slot >= 0 && slot < 54) {
                if (slot == 49) later(sp, () -> ShopHandler.open(sp));
                else if (slot == 45 && page > 0) later(sp, () -> open(sp, cat, page - 1));
                else if (slot == 53 && (page + 1) * PER < list.size()) later(sp, () -> open(sp, cat, page + 1));
                else if (slot < PER && page * PER + slot < list.size()) {
                    Entry e = list.get(page * PER + slot);
                    later(sp, () -> Qty.open(sp, cat, page, e, 1));
                }
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }

    // ===== 3) CHON SO LUONG (27 o) =====
    static class Qty extends GenericContainerScreenHandler {
        static final int MAX = 2304;
        final SimpleInventory inv; final String cat; final int page; final Entry e; int qty;

        static void open(ServerPlayerEntity p, String cat, int page, Entry e, int qty) {
            p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, inv, pl) -> new Qty(id, inv, new SimpleInventory(27), cat, page, e, qty),
                Text.literal("Chọn số lượng")));
        }

        Qty(int id, PlayerInventory pinv, SimpleInventory inv, String cat, int page, Entry e, int qty) {
            super(ScreenHandlerType.GENERIC_9X3, id, pinv, inv, 3);
            this.inv = inv; this.cat = cat; this.page = page; this.e = e; this.qty = qty;
            refresh();
        }

        void refresh() {
            fill(inv);
            inv.setStack(10, icon(Items.RED_WOOL, "§c-64"));
            inv.setStack(11, icon(Items.RED_WOOL, "§c-10"));
            inv.setStack(12, icon(Items.RED_WOOL, "§c-1"));
            ItemStack d = new ItemStack(e.item());
            d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal("§eQuantity: §f" + qty),
                Text.literal("§eTotal Cost: §a$" + Prices.money(e.price() * qty)))));
            inv.setStack(13, d);
            inv.setStack(14, icon(Items.LIME_WOOL, "§a+1"));
            inv.setStack(15, icon(Items.LIME_WOOL, "§a+10"));
            inv.setStack(16, icon(Items.LIME_WOOL, "§a+64"));
            inv.setStack(21, icon(Items.GREEN_WOOL, "§2§lXÁC NHẬN MUA", "§7Số lượng: " + qty, "§7Tổng: §a$" + Prices.money(e.price() * qty)));
            inv.setStack(25, icon(Items.BARRIER, "§c§lHỦY", "§7Quay lại menu trước"));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && button == 0 && slot >= 0 && slot < 27) {
                switch (slot) {
                    case 10 -> qty -= 64;
                    case 11 -> qty -= 10;
                    case 12 -> qty -= 1;
                    case 14 -> qty += 1;
                    case 15 -> qty += 10;
                    case 16 -> qty += 64;
                    case 25 -> { later(sp, () -> Category.open(sp, cat, page)); syncState(); return; }
                    case 21 -> { buy(sp); syncState(); return; }
                    default -> { }
                }
                qty = Math.max(1, Math.min(MAX, qty));
                refresh();
            }
            syncState();
        }

        void buy(ServerPlayerEntity sp) {
            double cost = e.price() * qty;
            if (!canReceive(sp, e.item(), qty)) return;
            if (DonutLike.bal(sp.getUuid()) < cost) {
                DonutLike.msg(sp, "§cYou don't have enough money! (cần $" + Prices.money(cost) + ")");
                return;
            }
            DonutLike.add(sp.getUuid(), -cost);
            int left = qty;
            while (left > 0) {
                int n = Math.min(e.item().getMaxCount(), left);
                sp.getInventory().offerOrDrop(new ItemStack(e.item(), n));
                left -= n;
            }
            ting(sp);
            DonutLike.msg(sp, "§aĐã mua " + qty + "x " + new ItemStack(e.item()).getName().getString() + " - $" + Prices.money(cost));
            // giu nguyen man hinh chon so luong de mua tiep (khong thoat ra man hinh chinh)
            refresh();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
