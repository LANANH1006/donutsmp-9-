package com.donutlike;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.*;

/**
 * Spawner kieu DonutSMP:
 *  - Chuot phai spawner dang dat bang spawner CUNG LOAI = gop them 1 (Shift = gop ca stack trong tay).
 *  - Dat spawner moi: Shift + dat = dat ca stack thanh 1 spawner x N.
 *  - Dao bang Silk Touch: lay 1 spawner ra khoi stack; Shift + dao = lay ca stack. Khong Silk Touch thi khong dao duoc.
 *  - Spawner khong sinh quai: tu sinh DO (loot) vao kho cua no. Chuot phai spawner (tay khong/khong Shift) = mo kho:
 *    click trai = lay 1 stack, click phai = ban het loai do do, nut "Ban tat ca".
 */
public class Spawners {

    public static class Data {
        public String mob = "pig";
        public int count = 1;
        public Map<String, Long> items = new HashMap<>();
    }

    static final Random R = new Random();
    /** mob -> {id item, min, max} moi 10 giay moi spawner trong stack */
    static final Map<String, Object[][]> LOOT = new HashMap<>();
    static {
        LOOT.put("pig", new Object[][]{{"porkchop", 1, 3}});
        LOOT.put("cow", new Object[][]{{"beef", 1, 3}, {"leather", 0, 2}});
        LOOT.put("skeleton", new Object[][]{{"bone", 0, 2}, {"arrow", 0, 2}});
        LOOT.put("blaze", new Object[][]{{"blaze_rod", 0, 1}});
        LOOT.put("creeper", new Object[][]{{"gunpowder", 0, 2}});
        LOOT.put("zombie", new Object[][]{{"rotten_flesh", 0, 2}});
        LOOT.put("spider", new Object[][]{{"string", 0, 2}, {"spider_eye", 0, 1}});
        LOOT.put("iron_golem", new Object[][]{{"iron_ingot", 3, 5}});
    }

    static Map<String, Data> map() {
        if (DonutLike.save.spawners == null) DonutLike.save.spawners = new HashMap<>();
        return DonutLike.save.spawners;
    }

    static String key(ServerWorld w, BlockPos p) {
        return w.getRegistryKey().getValue() + "|" + p.getX() + "," + p.getY() + "," + p.getZ();
    }

    static String mobOf(ItemStack s) {
        NbtComponent c = s.get(DataComponentTypes.BLOCK_ENTITY_DATA);
        if (c == null) return null;
        NbtCompound n = c.copyNbt();
        String id = n.getCompound("SpawnData").getCompound("entity").getString("id");
        if (id == null || id.isEmpty()) return null;
        return id.replace("minecraft:", "");
    }

    static boolean hasSilk(ItemStack s) {
        if (s.isEmpty()) return false;
        for (var e : s.getEnchantments().getEnchantments()) if (e.matchesKey(Enchantments.SILK_TOUCH)) return true;
        return false;
    }

    static Item item(String id) { return Registries.ITEM.get(Identifier.of("minecraft", id)); }

    static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || hand != Hand.MAIN_HAND || !(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw))
                return ActionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            ItemStack held = player.getStackInHand(hand);
            BlockState st = world.getBlockState(pos);
            String mobHeld = held.isOf(Items.SPAWNER) ? mobOf(held) : null;

            if (st.isOf(Blocks.SPAWNER)) {
                Data d = map().get(key(sw, pos));
                if (d == null) return ActionResult.PASS;
                if (mobHeld != null && mobHeld.equals(d.mob)) {                 // gop stack
                    int n = player.isSneaking() ? held.getCount() : 1;
                    if (!sp.isCreative()) held.decrement(n);
                    d.count += n;
                    ShopHandler.ting(sp);
                    sp.sendMessage(Text.literal("§aĐã gộp +" + n + " §7→ §d" + name(d.mob) + " Spawner x" + d.count), true);
                    return ActionResult.SUCCESS;
                }
                if (!player.isSneaking()) { openGui(sp, key(sw, pos)); return ActionResult.SUCCESS; }
                return ActionResult.PASS;
            }

            if (mobHeld != null) {                                              // dat spawner moi
                BlockPos placed = st.isReplaceable() ? pos : pos.offset(hit.getSide());
                int n = player.isSneaking() ? held.getCount() : 1;
                String mob = mobHeld;
                boolean creative = sp.isCreative();
                Duels.later(1, () -> {
                    if (!sw.getBlockState(placed).isOf(Blocks.SPAWNER)) return;
                    String k = key(sw, placed);
                    if (map().containsKey(k)) return;
                    Data nd = new Data();
                    nd.mob = mob;
                    nd.count = 1;
                    if (n > 1) {
                        int take = creative ? n - 1 : Math.min(n - 1, held.getCount());
                        if (!creative) held.decrement(take);
                        nd.count += take;
                    }
                    map().put(k, nd);
                });
            }
            return ActionResult.PASS;
        });

        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> {
            if (world.isClient || !state.isOf(Blocks.SPAWNER) || !(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld sw)) return true;
            Data d = map().get(key(sw, pos));
            if (d == null) return true;
            if (!hasSilk(sp.getMainHandStack())) {
                sp.sendMessage(Text.literal("§cCần cúp có §dSilk Touch §cđể đào spawner."), true);
                return false;
            }
            int give = Math.min(d.count, sp.isSneaking() ? d.count : 1);
            d.count -= give;
            while (give > 0) {
                int n = Math.min(64, give);
                sp.getInventory().offerOrDrop(ShardShop.spawner(d.mob).copyWithCount(n));
                give -= n;
            }
            if (d.count <= 0) {
                for (Map.Entry<String, Long> e : d.items.entrySet()) giveItems(sp, e.getKey(), e.getValue());
                map().remove(key(sw, pos));
                sw.breakBlock(pos, false);
                sp.sendMessage(Text.literal("§aĐã lấy hết spawner (đồ bên trong đã trả về túi)."), true);
            } else {
                sp.sendMessage(Text.literal("§aCòn lại §d" + name(d.mob) + " Spawner x" + d.count), true);
            }
            return false;
        });
    }

    static String name(String mob) { return mob.isEmpty() ? mob : mob.substring(0, 1).toUpperCase() + mob.substring(1); }

    static void giveItems(ServerPlayerEntity sp, String id, long amount) {
        Item it = item(id);
        while (amount > 0) {
            int n = (int) Math.min(it.getMaxCount(), amount);
            sp.getInventory().offerOrDrop(new ItemStack(it, n));
            amount -= n;
        }
    }

    /** moi 10 giay: moi spawner sinh do vao kho */
    static void tick(MinecraftServer s) {
        if (DonutLike.tick % 200 != 0 || map().isEmpty()) return;
        Iterator<Map.Entry<String, Data>> it = map().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Data> en = it.next();
            String[] a = en.getKey().split("\\|");
            String[] c = a[1].split(",");
            BlockPos pos = new BlockPos(Integer.parseInt(c[0]), Integer.parseInt(c[1]), Integer.parseInt(c[2]));
            ServerWorld w = s.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(a[0])));
            if (w == null) continue;
            if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) continue;
            if (!w.getBlockState(pos).isOf(Blocks.SPAWNER)) { it.remove(); continue; }
            Data d = en.getValue();
            Object[][] loot = LOOT.getOrDefault(d.mob, new Object[][]{{"bone", 1, 2}});
            for (Object[] l : loot) {
                int min = (Integer) l[1], max = (Integer) l[2];
                long add = 0;
                for (int i = 0; i < Math.min(d.count, 64); i++) add += min + R.nextInt(max - min + 1);
                if (d.count > 64) add = add * d.count / 64;
                if (add <= 0) continue;
                String id = (String) l[0];
                long cap = 100_000L * d.count;
                d.items.merge(id, add, Long::sum);
                if (d.items.get(id) > cap) d.items.put(id, cap);
            }
        }
    }

    // ===== GUI kho spawner =====
    static void openGui(ServerPlayerEntity p, String key) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (id, inv, pl) -> new Gui(id, inv, new SimpleInventory(54), key), Text.literal("Spawner")));
    }

    static class Gui extends GenericContainerScreenHandler {
        final SimpleInventory inv; final String key; final List<String> ids = new ArrayList<>();
        int qty = 64; // so luong moi lan lay/ban (chinh bang nut + -)

        Gui(int id, PlayerInventory pinv, SimpleInventory inv, String key) {
            super(ScreenHandlerType.GENERIC_9X6, id, pinv, inv, 6);
            this.inv = inv; this.key = key;
            refresh();
        }

        void refresh() {
            for (int i = 0; i < 54; i++) inv.setStack(i, ItemStack.EMPTY);
            Data d = map().get(key);
            ids.clear();
            if (d == null) return;
            ids.addAll(d.items.keySet());
            double total = 0;
            for (int i = 0; i < ids.size() && i < 45; i++) {
                String id = ids.get(i);
                long n = d.items.get(id);
                Item it = item(id);
                double v = Prices.unit(it) * n * Prices.SELL_RATE;
                total += v;
                ItemStack s = new ItemStack(it, (int) Math.max(1, Math.min(64, n)));
                s.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§eTrong kho: §f" + Prices.money(n)),
                    Text.literal("§eGiá trị: §a$" + Prices.money(v)),
                    Text.literal("§aClick trái: lấy §f" + qty + " §7| §aClick phải: bán §f" + qty + " §7(chỉnh bằng + -)"))));
                inv.setStack(i, s);
            }
            for (int i = 45; i < 54; i++) inv.setStack(i, ShopHandler.icon(Items.GRAY_STAINED_GLASS_PANE, " "));
            inv.setStack(45, ShopHandler.icon(Items.RED_WOOL, "§c§l- Giảm", "§7Chuột trái: -1", "§7Chuột phải: -10", "§7Shift: -64"));
            ItemStack q = ShopHandler.icon(Items.PAPER, "§eSố lượng mỗi lần: §f" + qty, "§7Dùng + - để chỉnh");
            q.setCount(Math.max(1, Math.min(64, qty)));
            inv.setStack(46, q);
            inv.setStack(47, ShopHandler.icon(Items.LIME_WOOL, "§a§l+ Tăng", "§7Chuột trái: +1", "§7Chuột phải: +10", "§7Shift: +64"));
            inv.setStack(48, ShopHandler.icon(Items.SPAWNER, "§d" + name(d.mob) + " Spawner x" + d.count, "§7Sinh đồ vào kho mỗi 10 giây"));
            inv.setStack(49, ShopHandler.icon(Items.EMERALD, "§a§lBán tất cả", "§7Tổng giá trị: §a$" + Prices.money(total)));
        }

        @Override
        public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
            if (player instanceof ServerPlayerEntity sp && type == SlotActionType.PICKUP && slot >= 0 && slot < 54) {
                Data d = map().get(key);
                if (d == null) { ShopHandler.later(sp, sp::closeHandledScreen); syncState(); return; }
                if (slot == 45 || slot == 47) {
                    int step = type == SlotActionType.PICKUP && button == 1 ? 10 : 1;
                    if (player.isSneaking()) step = 64;
                    qty = Math.max(1, Math.min(10_000, qty + (slot == 47 ? step : -step)));
                } else if (slot == 49) {
                    double total = 0;
                    for (Map.Entry<String, Long> e : d.items.entrySet()) total += Prices.unit(item(e.getKey())) * e.getValue() * Prices.SELL_RATE;
                    d.items.clear();
                    if (total > 0) { DonutLike.add(sp.getUuid(), total); ShopHandler.ting(sp); DonutLike.msg(sp, "§aĐã bán đồ trong spawner: §e+$" + Prices.money(total)); }
                } else if (slot < 45 && slot < ids.size()) {
                    String id = ids.get(slot);
                    Long have = d.items.get(id);
                    if (have != null && have > 0) {
                        if (button == 1) {
                            long sell = Math.min(have, qty);
                            double v = Prices.unit(item(id)) * sell * Prices.SELL_RATE;
                            if (have - sell <= 0) d.items.remove(id); else d.items.put(id, have - sell);
                            DonutLike.add(sp.getUuid(), v);
                            ShopHandler.ting(sp);
                            DonutLike.msg(sp, "§aĐã bán: §e+$" + Prices.money(v));
                        } else {
                            Item it = item(id);
                            long want = Math.min(have, qty);
                            if (!Admin.on("shop_dropfull")) want = Math.min(want, ShopHandler.space(sp, it));
                            if (want <= 0) { DonutLike.msg(sp, "§cTúi đồ đầy! Hãy dọn chỗ trống."); refresh(); syncState(); return; }
                            giveItems(sp, id, want);
                            if (have - want <= 0) d.items.remove(id); else d.items.put(id, have - want);
                        }
                    }
                }
                refresh();
            }
            syncState();
        }

        @Override public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
    }
}
