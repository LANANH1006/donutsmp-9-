package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BedBlock;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.world.World;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Chong lag kieu DonutSMP cu:
 *  1) Gop quai (mob stacking): "Creeper x100", chem chet tru 1, roi loot 1 con.
 *  2) Don item roi duoi dat khi qua nhieu.
 *  3) Do Amethyst tu huy sau 72h (thoi gian thuc), thong bao mau tim.
 *  4) Khoa no giuong (Nether/End) va Respawn Anchor (ngoai Nether). TNT + End Crystal van no binh thuong.
 */
public class AntiLag {
    static int maxStack() { return Admin.inum("max_stack"); }
    static final int MERGE_INTERVAL_TICKS = 100;   // 5s
    static int itemCap() { return Admin.inum("item_cap"); }
    static long amethystLifetimeMs() { return (long) (Admin.num("amethyst_hours") * 3600_000L); }
    static final String STACK_PREFIX = "dlstack:";

    static final Map<String, Item> AMETHYST_BASE = new LinkedHashMap<>();
    static {
        AMETHYST_BASE.put("sword", Items.NETHERITE_SWORD); AMETHYST_BASE.put("pickaxe", Items.NETHERITE_PICKAXE);
        AMETHYST_BASE.put("axe", Items.NETHERITE_AXE); AMETHYST_BASE.put("shovel", Items.NETHERITE_SHOVEL);
        AMETHYST_BASE.put("helmet", Items.NETHERITE_HELMET); AMETHYST_BASE.put("chestplate", Items.NETHERITE_CHESTPLATE);
        AMETHYST_BASE.put("leggings", Items.NETHERITE_LEGGINGS); AMETHYST_BASE.put("boots", Items.NETHERITE_BOOTS);
        AMETHYST_BASE.put("bucket", Items.WATER_BUCKET);       // xo nuoc vo han
        AMETHYST_BASE.put("hammer", Items.NETHERITE_PICKAXE);  // (cu) cup 3x3
        AMETHYST_BASE.put("pick", Items.NETHERITE_PICKAXE);    // cup dao 3 o dai x 1 ngang
        AMETHYST_BASE.put("treeaxe", Items.NETHERITE_AXE);     // riu chat ca cay
        AMETHYST_BASE.put("sellaxe", Items.NETHERITE_AXE);     // riu ban ruong
        AMETHYST_BASE.put("potion", Items.POTION);             // thuoc x2.5 shard
    }
    static final Map<String, String[]> AMETHYST_INFO = new LinkedHashMap<>();
    static {
        AMETHYST_INFO.put("bucket", new String[]{"Amethyst Bucket", "Múc nước 3x3x1 / đặt nước 3 ngang x 1 cao, không mất hiệu ứng"});
        AMETHYST_INFO.put("pick", new String[]{"Amethyst Pickaxe", "Đào 1 lần = 3 block thẳng hàng (dài 3, ngang 1)"});
        AMETHYST_INFO.put("shovel", new String[]{"Amethyst Shovel", "Đào cát/đất/sỏi 1 lần = 3 block thẳng hàng (dài 3, ngang 1)"});
        AMETHYST_INFO.put("hammer", new String[]{"Amethyst Pickaxe 3x3", "Đào 3x3 (nhìn xuống: đào 3x3 sâu 3 ô)"});
        AMETHYST_INFO.put("treeaxe", new String[]{"Amethyst Axe (Cây)", "Chặt 1 khúc gỗ = đổ cả cây, lá biến mất"});
        AMETHYST_INFO.put("sellaxe", new String[]{"Amethyst Axe (Sell)", "Đào rương = bán toàn bộ đồ trong rương (rương không bị phá)"});
        AMETHYST_INFO.put("potion", new String[]{"Amethyst Potion", "Chuột phải: x2.5 shard trong 30 phút"});
    }

    // ---------- stack helpers (luu trong command tags => ton tai qua restart) ----------
    static int getCount(Entity e) {
        for (String t : e.getCommandTags()) if (t.startsWith(STACK_PREFIX)) {
            try { return Integer.parseInt(t.substring(STACK_PREFIX.length())); } catch (Exception ignored) {}
        }
        return 0;
    }

    static void setCount(MobEntity m, int n) {
        for (String t : new ArrayList<>(m.getCommandTags())) if (t.startsWith(STACK_PREFIX)) m.removeCommandTag(t);
        if (n > 1) {
            m.addCommandTag(STACK_PREFIX + n);
            m.setCustomName(Text.literal("§c" + m.getType().getName().getString() + " x" + n));
            m.setCustomNameVisible(true);
        } else {
            m.setCustomName(null);
            m.setCustomNameVisible(false);
        }
    }

    static boolean stackable(Entity e) {
        if (!(e instanceof HostileEntity m) || !m.isAlive()) return false;
        if (m instanceof WitherEntity || m.hasVehicle() || m.hasPassengers()) return false;
        return !m.hasCustomName() || getCount(m) > 0; // bo qua quai co ten (boss, bot duel...)
    }

    // ---------- init ----------
    static void init() {
        // chem chet 1 con trong stack -> sinh lai stack con (count-1), con vua chet roi loot binh thuong
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, src) -> {
            if (!Admin.on("mobstack") || !(entity instanceof MobEntity m) || !(m.getWorld() instanceof ServerWorld w)) return;
            int n = getCount(m);
            if (n <= 1) return;
            Entity e = m.getType().create(w, SpawnReason.EVENT);
            if (e instanceof MobEntity clone) {
                clone.refreshPositionAndAngles(m.getX(), m.getY(), m.getZ(), m.getYaw(), 0);
                setCount(clone, n - 1);
                w.spawnEntity(clone);
            }
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient) return ActionResult.PASS;
            var pos = hit.getBlockPos();
            var block = world.getBlockState(pos).getBlock();
            // khoa no giuong / anchor
            if (Admin.on("bedlock") && block instanceof BedBlock && !world.getRegistryKey().equals(World.OVERWORLD)) {
                player.sendMessage(Text.literal("§cGiường bị khoá ở thế giới này (chống nổ/lag)."), true);
                return ActionResult.FAIL;
            }
            if (Admin.on("anchorlock") && block instanceof RespawnAnchorBlock && !world.getRegistryKey().equals(World.NETHER)) {
                player.sendMessage(Text.literal("§cRespawn Anchor bị khoá ở thế giới này."), true);
                return ActionResult.FAIL;
            }
            // mo ruong -> quet Amethyst het han
            if (Admin.on("amethyst") && world.getBlockEntity(pos) instanceof Inventory inv) purge(inv, null);
            return ActionResult.PASS;
        });
    }

    // ---------- moi giay ----------
    static void everySecond(MinecraftServer s) {
        long t = DonutLike.tick;
        if (t % MERGE_INTERVAL_TICKS == 0 && Admin.on("mobstack")) for (ServerWorld w : s.getWorlds()) mergeMobs(w);
        if (t % 200 == 0 && Admin.on("itemclean")) for (ServerWorld w : s.getWorlds()) cleanItems(w);
        if (t % 200 == 0 && Admin.on("amethyst")) for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            purge(p.getInventory(), p);
            purge(p.getEnderChestInventory(), p);
        }
    }

    static void mergeMobs(ServerWorld w) {
        Map<String, List<HostileEntity>> groups = new HashMap<>();
        List<Entity> all = new ArrayList<>();
        for (Entity e : w.iterateEntities()) all.add(e);
        for (Entity e : all) {
            if (!stackable(e)) continue;
            HostileEntity m = (HostileEntity) e;
            String key = m.getType().getTranslationKey() + ":" + ((int) m.getX() >> 3) + ":" + ((int) m.getY() >> 2) + ":" + ((int) m.getZ() >> 3);
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(m);
        }
        for (List<HostileEntity> g : groups.values()) {
            if (g.size() < 2) continue;
            HostileEntity keep = g.get(0);
            int total = Math.max(1, getCount(keep));
            for (int i = 1; i < g.size(); i++) {
                HostileEntity o = g.get(i);
                int c = Math.max(1, getCount(o));
                if (total + c > maxStack()) continue;
                total += c;
                o.discard();
            }
            if (total > 1) setCount(keep, total);
        }
    }

    static void cleanItems(ServerWorld w) {
        List<ItemEntity> items = new ArrayList<>();
        for (Entity e : w.iterateEntities()) if (e instanceof ItemEntity ie) items.add(ie);
        if (items.size() <= itemCap()) return;
        for (ItemEntity ie : items) if (ie.getItemAge() > 1200) ie.discard();
    }

    // ---------- Amethyst ----------
    static boolean expired(ItemStack s) {
        if (s.isEmpty()) return false;
        NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
        if (c == null) return false;
        NbtCompound n = c.copyNbt();
        return n.contains("dl_expire") && System.currentTimeMillis() >= n.getLong("dl_expire");
    }

    static void purge(Inventory inv, ServerPlayerEntity notify) {
        int removed = 0;
        for (int i = 0; i < inv.size(); i++) {
            if (expired(inv.getStack(i))) { inv.setStack(i, ItemStack.EMPTY); removed++; }
        }
        if (removed > 0 && notify != null) notify.sendMessage(Text.literal("§5Sức mạnh của Amethyst đã cạn kiệt"), false);
    }

    /** Cac bien the co enchant (silk/fortune) cho cong cu. */
    static final List<String> VARIANT_BASES = List.of("pick", "shovel", "treeaxe", "sellaxe");

    /** Tat ca "spec" hop le: sword, bucket, pick_silk, pick_fortune, ... */
    static List<String> allSpecs() {
        List<String> l = new ArrayList<>();
        for (String k : AMETHYST_BASE.keySet()) {
            if (k.equals("hammer")) continue;
            if (VARIANT_BASES.contains(k)) { l.add(k + "_silk"); l.add(k + "_fortune"); }
            else l.add(k);
        }
        return l;
    }

    static boolean validSpec(String spec) { return allSpecs().contains(spec) || AMETHYST_BASE.containsKey(spec); }

    /** Unbreaking 3 + Mending + Efficiency 5 + (Silk Touch | Fortune 3) */
    static void enchantTool(ItemStack s, String variant) {
        if (DonutLike.SERVER == null) return;
        var reg = DonutLike.SERVER.getRegistryManager().getOrThrow(net.minecraft.registry.RegistryKeys.ENCHANTMENT);
        s.addEnchantment(reg.getOrThrow(net.minecraft.enchantment.Enchantments.UNBREAKING), 3);
        s.addEnchantment(reg.getOrThrow(net.minecraft.enchantment.Enchantments.MENDING), 1);
        s.addEnchantment(reg.getOrThrow(net.minecraft.enchantment.Enchantments.EFFICIENCY), 5);
        if (variant.equals("silk")) s.addEnchantment(reg.getOrThrow(net.minecraft.enchantment.Enchantments.SILK_TOUCH), 1);
        else s.addEnchantment(reg.getOrThrow(net.minecraft.enchantment.Enchantments.FORTUNE), 3);
    }

    static ItemStack makeAmethyst(String spec) {
        String type = spec, variant = "";
        for (String v : new String[]{"silk", "fortune"}) {
            if (spec.endsWith("_" + v)) { type = spec.substring(0, spec.length() - v.length() - 1); variant = v; }
        }
        if (type.equals("hammer")) type = "pick";
        Item base = AMETHYST_BASE.get(type);
        ItemStack s = new ItemStack(base);
        long exp = System.currentTimeMillis() + amethystLifetimeMs();
        NbtCompound n = new NbtCompound();
        n.putByte("dl_amethyst", (byte) 1);
        n.putString("dl_kind", type);
        n.putString("dl_variant", variant);
        n.putLong("dl_expire", exp);
        s.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(n));
        String[] info = AMETHYST_INFO.get(type);
        String suffix = variant.equals("silk") ? " §f(Silk Touch)" : variant.equals("fortune") ? " §f(Fortune III)" : "";
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal("§d" + (info != null ? info[0] : "Amethyst " + type.substring(0, 1).toUpperCase() + type.substring(1)) + suffix));
        if (!variant.isEmpty()) enchantTool(s, variant);
        List<Text> lore = new ArrayList<>();
        if (info != null) lore.add(Text.literal("§f" + info[1]));
        if (!variant.isEmpty()) lore.add(Text.literal("§7Unbreaking III, Mending, Efficiency V, " + (variant.equals("silk") ? "Silk Touch" : "Fortune III")));
        lore.add(Text.literal("§5Tự huỷ sau " + Admin.inum("amethyst_hours") + " giờ (thời gian thực)"));
        lore.add(Text.literal("§7Hết hạn: " + new Date(exp)));
        s.set(DataComponentTypes.LORE, new LoreComponent(lore));
        return s;
    }

    static void register(CommandDispatcher<ServerCommandSource> d) {
        // /amethyst <player> <sword|pickaxe|...> (op)
        d.register(literal("amethyst").requires(src -> Admin.isAdmin(src) && Admin.on("amethyst"))
            .then(argument("player", EntityArgumentType.player())
            .then(argument("type", StringArgumentType.word()).suggests((c, b) -> {
                allSpecs().forEach(b::suggest); return b.buildFuture(); })
            .executes(c -> {
                String type = StringArgumentType.getString(c, "type");
                if (!validSpec(type)) { c.getSource().sendError(Text.literal("Loại: " + allSpecs())); return 0; }
                EntityArgumentType.getPlayer(c, "player").getInventory().offerOrDrop(makeAmethyst(type));
                return 1;
            }))));
    }
}
